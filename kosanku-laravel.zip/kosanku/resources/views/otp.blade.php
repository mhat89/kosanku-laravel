<!doctype html>
<html>
  <body>
    <p>Kode OTP Anda: <strong>{{ $code }}</strong></p>
    <p>Berlaku {{ $ttlMinutes }} menit. Jangan bagikan.</p>
  </body>
</html>
