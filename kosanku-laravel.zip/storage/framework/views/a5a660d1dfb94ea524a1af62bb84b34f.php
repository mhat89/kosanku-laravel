<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title><?php echo $__env->yieldContent('title','Kosanku'); ?></title>
  <style>
    body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial;margin:24px}
    header{display:flex;justify-content:space-between;align-items:center;margin-bottom:24px}
    nav form{margin:0}
    nav button{background:#f03e3e;color:#fff;border:none;padding:8px 12px;border-radius:4px;cursor:pointer}
    nav button:hover{background:#c92a2a}
    .container{max-width:640px;margin:auto}
    .msg{padding:10px;background:#e7f5ff;border:1px solid #a5d8ff;border-radius:6px;margin-bottom:12px}
    .err{color:#c92a2a;margin-bottom:12px}
  </style>
</head>
<body>
  <header>
    <h1>Kosanku</h1>
    <nav>
    <?php if(session('api_token')): ?>
      <form method="POST" action="<?php echo e(route('logout.web')); ?>">
        <?php echo csrf_field(); ?>
        <button type="submit">Logout</button>
      </form>
    <?php else: ?>
      <a href="<?php echo e(route('login.show')); ?>">Login</a>
    <?php endif; ?>
  </nav>

  </header>

  <div class="container">
    <?php if(session('status')): ?> <div class="msg"><?php echo e(session('status')); ?></div> <?php endif; ?>
    <?php if($errors->any()): ?>
      <div class="err">
        <ul>
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
    <?php endif; ?>

    <?php echo $__env->yieldContent('content'); ?>
  </div>
</body>
</html>
<?php /**PATH D:\Project\kosanku-laravel\resources\views/layouts/app.blade.php ENDPATH**/ ?>