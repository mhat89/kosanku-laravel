

<?php $__env->startSection('title','Login'); ?>

<?php $__env->startSection('content'); ?>
  <h2>Login</h2>

  <?php if(session('status')): ?> <div class="msg"><?php echo e(session('status')); ?></div> <?php endif; ?>
  <?php if(session('error')): ?>  <div class="err"><?php echo e(session('error')); ?></div> <?php endif; ?>

  <form method="POST" action="<?php echo e(route('login.post')); ?>" novalidate>
    <?php echo csrf_field(); ?>
    <label>Email</label>
    <input name="email" type="email" value="<?php echo e(old('email')); ?>" required autofocus>

    <label>Password</label>
    <input name="password" type="password" required>

    <button type="submit">Login</button>
  </form>

  <p style="margin-top:12px">
    Lupa password? <a href="<?php echo e(route('forgot.show')); ?>">Reset di sini</a>
  </p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project\kosanku-laravel\resources\views/authweb/login.blade.php ENDPATH**/ ?>