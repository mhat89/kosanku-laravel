

<?php $__env->startSection('title','Dashboard'); ?>

<?php $__env->startSection('content'); ?>
  <h2>Dashboard</h2>
  <p>Selamat datang! Anda sudah login.</p>

  <div style="margin-top:20px">
    <h3>Token API (disimpan di session):</h3>
    <code><?php echo e(session('api_token')); ?></code>
  </div>

  <div style="margin-top:20px">
    <p>Di sini nanti bisa tampilkan data user, peta, dsb.</p>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project\kosanku-laravel\resources\views/authweb/dashboard.blade.php ENDPATH**/ ?>